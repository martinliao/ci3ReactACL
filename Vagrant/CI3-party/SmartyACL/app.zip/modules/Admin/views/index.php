<?php $this->load->view('header'); ?>

    <div class="container">
        <div class="row">
            <div class="col-6 offset-lg-3">
                <div class="card">
                    <div class="card-header">
                        Admin Home
                    </div>
                    <div class="card-body">
                        Content
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $this->load->view('footer'); ?>